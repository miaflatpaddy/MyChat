const http = require('http');
const url = require('url');
const express = require('express');
var app = express();
const hostname = '127.0.0.1';
const port = 3000;
const mysql = require("mysql");


app.listen(port,hostname,()=>{console.log(`Server running at http://${hostname}:${port}/`);});
app.get("/userRegistration",(req, res) => {
    console.log("userRegistration");
    console.log(req.url);
    console.log(req.path);
    console.log(req.query);
    const connection = mysql.createPool({
        host: "localhost",
        user: "root",
        password: "",
        database: "chatdb"
    });

    const sql = 'INSERT INTO users(name, mail, password,nickname,isonline) VALUES(\'' + req.query.name + '\',\'' + req.query.email + '\',\'' + req.query.password + '\',\'' + req.query.nickname + '\',0)'

    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/plain');
    try {
        connection.query(sql, function (err, results) {
            if (err) {
                console.log(err);
                res.end("Error occurred: " + err.message);
            }
            console.log(results);
            res.end("Successfully");
        })
    } catch (err) {
        console.log(err);
    }
})
app.get("/updateStatus",(req, res) => {
    console.log("Update Status");
    console.log(req.url);
    console.log(req.path);
    console.log(req.query);
    const connection = mysql.createPool({
        host: "localhost",
        user: "root",
        password: "",
        database: "chatdb"
    });

    const sql = 'UPDATE users SET isonline = '+ req.query.isOnline +' WHERE id = ' + req.query.id;

    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/plain');
    try {
        connection.query(sql, function (err, results) {
            if (err) {
                console.log(err);
                res.end("Error occurred: " + err.message);
            }
            console.log(results);
            res.end("Successfully");
        })
    } catch (err) {
        console.log(err);
    }
})
app.get('/getUsers', function (req, res) {
    console.log("getUsers");
    console.log(req.url);
    console.log(req.path);
    console.log(req.query);
    const connection = mysql.createPool({
        host: "localhost",
        user: "root",
        password: "",
        database: "chatdb"
    });

    const sql = 'SELECT * FROM users'

    res.statusCode = 200;

    try {
        connection.query(sql, function (err, results) {
            if (err) {
                console.log(err);
                res.setHeader('Content-Type', 'text/plain');
                res.end("Error occurred: " + err.message);
            }
            const users = results;
            let json = JSON.stringify(users);
            console.log(results);
            res.setHeader('Content-Type', 'application/json');
            res.end(json);
        })
    } catch (err) {
        console.log(err);
    }
})
app.get("/addMessage",(req, res) => {
    console.log("addMessage");
    console.log(req.url);
    console.log(req.path);
    console.log(req.query);
    const connection = mysql.createPool({
        host: "localhost",
        user: "root",
        password: "",
        database: "chatdb"
    });

    const sql = 'INSERT INTO messages(author,message,isnew) VALUES(\'' + req.query.author + '\',\'' + req.query.msg + '\',1)'
    console.log(sql);
    res.statusCode = 200;
    res.setHeader('Content-Type', 'text/plain');
    try {
        connection.query(sql, function (err, results) {
            if (err) {
                console.log(err);
                res.end("Error occurred: " + err.message);
            }
            console.log(results);
            res.end("Successfully");
        })
    } catch (err) {
        console.log(err);
    }
})
app.get('/getMessages', function (req, res) {
    console.log("getMessages");
    console.log(req.url);
    console.log(req.path);
    console.log(req.query);
    const connection = mysql.createPool({
        host: "localhost",
        user: "root",
        password: "",
        database: "chatdb"
    });

    const sql = 'SELECT * FROM messages'

    res.statusCode = 200;

    try {
        connection.query(sql, function (err, results) {
            if (err) {
                console.log(err);
                res.setHeader('Content-Type', 'text/plain');
                res.end("Error occurred: " + err.message);
            }
            const messages = results;
            console.log(messages.length)
            for(let i = 0; i < messages.length; i++) {
                if(messages[i].isnew==1) {
                    const sql1 = 'UPDATE messages SET isnew = ' + 0 + ' WHERE id = ' + messages[i].id;
                    connection.query(sql1, function (err, results) {
                        if (err) {
                            console.log(err);
                        }
                        console.log(results);
                    })
                }
            }
            let json = JSON.stringify(messages);
            console.log(results);
            res.setHeader('Content-Type', 'application/json');
            res.end(json);
        })
    } catch (err) {
        console.log(err);
    }
})
// const server = http.createServer((req, res) => {
//     console.log("server started");
//     console.log(req.url);
//     console.log(req.query)
//     if(req.url==="/userregistration"){
//         console.log("userregistration");
//
//         const sql = 'INSERT INTO users(name, email, password,nickname,isonline) VALUES(${req.query.name},${req.query.email},${req.query.password},${req.query.nickname},0)'
//         connection.query(sql,function(err,results){
//             if(err){console.log(err);}
//             console.log(results);
//         })
//     }
//
//     res.statusCode = 200;
//     res.setHeader('Content-Type', 'application/json');
//     res.end(JSON.stringify({a:1}));
// });
//
// server.listen(port, hostname, () => {
//     console.log(`Server running at http://${hostname}:${port}/`);
// });